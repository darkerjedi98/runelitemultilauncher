print("Runelite MultiLauncher By DarkerJedi98")
import base64
import os
print("epic!")
print("place this file in the same location as RuneLite.exe!")
print("This will launch Oldschool Runescape Via Runelite! *works on windows 10 / 8 / 7 ")
input("Press Enter to continue...")
print("how many instances would you like to launch ? up to 4")
print(" x=1 z=2 y=3 a=4 b=0 ")
option1 = input("enter selection:")
if option1 == "x":
	os.startfile(r'Runelite.exe')
	print("thank you for using darkerjedi's runescape launcher!")
	input("Press Enter to continue...")
	print("would you like to launch calculator and notepad?")
	print(" a=launch both b=launch only calc c=launch only notepad n=launch none ")
	option3 = input("enter selection:")
	if option3 == "a":
		print("launching notepad and calculator")
		os.startfile(r'notepad.exe')
		os.startfile(r'calc')
		input("Press Enter to continue...")
	if option3 == "b":
		print("launching calculator")
		os.startfile(r'calc')
		input("Press Enter to continue...")
	if option3 == "c":
		print("launching notepad")
		os.startfile(r'notepad.exe')
		input("Press Enter to continue...")
	if option3 == "n":
		print("Thank you for Using Darkerjedi's Runelite Launcher!")
		input("Press Enter to continue...")
if option1 == "z":
	os.startfile(r'Runelite.exe')
	os.startfile(r'Runelite.exe')
	print("thank you for using darkerjedi's runescape launcher!")
	input("Press Enter to continue...")
	print("would you like to launch calculator and notepad?")
	print(" a=launch both b=launch only calc c=launch only notepad n=launch none")
	option3 = input("enter selection:")
	if option3 == "a":
		print("launching notepad and calculator")
		os.startfile(r'notepad.exe')
		os.startfile(r'calc')
		input("Press Enter to continue...")
	if option3 == "b":
		print("launching calculator")
		os.startfile(r'calc')
		input("Press Enter to continue...")
	if option3 == "c":
		print("launching notepad")
		os.startfile(r'notepad.exe')
		input("Press Enter to continue...")
	if option3 == "n":
		print("Thank you for Using Darkerjedi's Runelite Launcher!")
		input("Press Enter to continue...")
if option1 == "y":
	os.startfile(r'Runelite.exe')
	os.startfile(r'Runelite.exe')
	os.startfile(r'Runelite.exe')
	print("thank you for using darkerjedi's runescape launcher!")
	input("Press Enter to continue...")
	print("would you like to launch calculator and notepad?")
	print(" a=launch both b=launch only calc c=launch only notepad n=launch none ")
	option3 = input("enter selection:")
	if option3 == "a":
		print("launching notepad and calculator")
		os.startfile(r'notepad.exe')
		os.startfile(r'calc')
		input("Press Enter to continue...")
	if option3 == "b":
		print("launching calculator")
		os.startfile(r'calc')
		input("Press Enter to continue...")
	if option3 == "c":
		print("launching notepad")
		os.startfile(r'notepad.exe')
		input("Press Enter to continue...")
	if option3 == "n":
		print("Thank you for Using Darkerjedi's Runelite Launcher!")
		input("Press Enter to continue...")
if option1 == "a":
	os.startfile(r'Runelite.exe')
	os.startfile(r'Runelite.exe')
	os.startfile(r'Runelite.exe')
	os.startfile(r'Runelite.exe')
	print("thank you for using darkerjedi's runescape launcher!")
	input("Press Enter to continue...")
	print("would you like to launch calculator and notepad?")
	print(" a=launch both b=launch only calc c=launch only notepad n=launch none")
	option3 = input("enter selection:")
	if option3 == "a":
		print("launching notepad and calculator")
		os.startfile(r'notepad.exe')
		os.startfile(r'calc')
		input("Press Enter to continue...")
	if option3 == "b":
		print("launching calculator")
		os.startfile(r'calc')
		input("Press Enter to continue...")
	if option3 == "c":
		print("launching notepad")
		os.startfile(r'notepad.exe')
		input("Press Enter to continue...")
	if option3 == "n":
			print("Thank you for Using Darkerjedi's Runelite Launcher!")
			input("Press Enter to continue...")
if option1 == "b":
	print("thank you for using darkerjedi's runescape launcher!")
	input("Press Enter to continue...")
	print("would you like to launch calculator and notepad?")
	print(" a=launch both b=launch only calc c=launch only notepad n=launch none n=launch none")
	option3 = input("enter selection:")
	if option3 == "a":
		print("launching notepad and calculator")
		os.startfile(r'notepad.exe')
		os.startfile(r'calc')
		input("Press Enter to continue...")
	if option3 == "b":
		print("launching calculator")
		os.startfile(r'calc')
		input("Press Enter to continue...")
	if option3 == "c":
		print("launching notepad")
		os.startfile(r'notepad.exe')
		input("Press Enter to continue...")
	if option3 == "n":
		print("Thank you for Using Darkerjedi's Runelite Launcher!")
		input("Press Enter to continue...")