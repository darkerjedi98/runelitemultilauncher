import tkinter as tk
import os
import keyboard

def open():
    os.startfile(r'notepad.exe')
def open2():
    os.startfile(r'code1.py')
def open3():
    os.startfile(r'calc')
def open4():
    os.startfile(r'RuneLite.exe')

HEIGHT = 220
WIDTH = 270

root = tk.Tk()
root.title("Darkerjedi's Launcher")
canvas = tk.Canvas(root, height=HEIGHT, width=WIDTH,)
canvas.pack()

button = tk.Button(root, text="classic multi launcher", bg='green', fg='black', height=3, width=17, command=open2)

button.pack(side='left')

button = tk.Button(root, text="Runelite", bg='green', fg='black', height=3, width=17, command=open4)

button.pack(side='left')


button = tk.Button(root, text="notepad", bg='green', fg='black', height=3, width=7, command=open)

button.pack(side='right')

button = tk.Button(root, text="calc", bg='green', fg='black', height=3, width=5, command=open3)

button.pack(side='right')

root.mainloop()