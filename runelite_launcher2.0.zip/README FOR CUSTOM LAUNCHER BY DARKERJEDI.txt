Place the .py files in the RuneLite Directory , you will need python and keyboard
plugin for python included in this zip file, simply run and install the keyboard.exe
you can right click the launcher.py and create desktop shortcut to make things easier
, Enjoy!
