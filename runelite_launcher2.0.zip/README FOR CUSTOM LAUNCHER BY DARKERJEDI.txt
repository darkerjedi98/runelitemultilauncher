Place the .py file in the RuneLite Directory
default username is:

admin

password is:

default

