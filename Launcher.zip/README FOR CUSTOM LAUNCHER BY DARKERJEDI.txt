Place the files in the runelite directory. Enjoy!
